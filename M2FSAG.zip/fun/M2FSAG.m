function model = M2FSAG( Y, G, optmParameter)
%% optimization parameters
alpha          = optmParameter.alpha;
gamma          = optmParameter.gamma;
lamda  = optmParameter.lamda;
lamda1  = optmParameter.lamda1;
maxIter          = optmParameter.maxIter;
miniLossMargin   = optmParameter.minimumLossMargin;
num_dim   = size(G,2);
num = size(G,1);
num_class = size(Y,2);
G = G';

%% initialization

B = rand(num_class,num_class);
P   = (G*G'+lamda1*eye(num_dim)) \ (G*Y);
P_1 = P; 
iter = 1; oldloss = 0;
bk = 1; bk_1 = 1;

H = eye(num)-(1/num)*ones(num,1)*ones(num,1)';
 try
    qpOptions = optimoptions('quadprog','Display','off');
catch
    qpOptions = optimset('Display','off');
end
while iter <= maxIter

    
    L = diag((sum(B,2)+(sum(B))')/2) - (B'+B)/2; 
    lip = 2*norm(G*H*G')^2+2*lamda*norm(G*G')^2*norm(L)^2;
    Lip = sqrt(lip);

    %% update P
    P_k = P + (bk_1 - 1)/bk * (P - P_1);
    GP_k = P_k - 1/Lip * gradientOfP(G,P,Y,B,L,lamda,H);
    P_1 = P;
    P = softthres(GP_k,alpha/Lip);
    bk_1   = bk;
    bk     = (1 + sqrt(4*bk^2 + 1))/2;

    %% update B
    N = Y'*H*Y+gamma*Y'*Y;
    V = -0.5*(Y'*H*G'*P+gamma*Y'*Y);
    A = [];
    b = [];
    Aeq = ones(1,num_class);
    beq = 1;
    lb = zeros(num_class,1);
    ub = ones(num_class,1);
    for j = 1:num_class
        f = V(:,j);
        B(:,j) = quadprog(N,f,A,b,Aeq,beq,lb,ub,[],qpOptions);
    end


    %% Loss
    LS = H*G'*P - H*Y*B;
    DiscriminantLoss = trace(LS'*LS);
    LS = Y - Y*B;
    CorrelationLoss  = trace(LS'*LS);
    CorrelationLoss2 = trace(G'*P*L*P'*G);
    sparesP    = sum(sum(P~=0));
    totalloss = DiscriminantLoss + gamma*CorrelationLoss + alpha*sparesP +lamda*CorrelationLoss2;
    loss(iter,1) = totalloss;
    if abs((oldloss - totalloss)/oldloss) <= miniLossMargin
        break;
    elseif totalloss <=0
        break;
    else
        oldloss = totalloss;
    end
    iter=iter+1;
end
model.P = P;
model.loss = loss;
model.optmParameter = optmParameter;
end

%% soft thresholding operator
function W = softthres(W_t,lambda)
W = max(W_t-lambda,0) - max(-W_t-lambda,0);
end

function gradient = gradientOfP(G,P,Y,B,L,lamda,H)
gradient = G*H*G'*P - G*H*Y*B+lamda*G*G'*P*L;
end
