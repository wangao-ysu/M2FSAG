clear all
clc
clear
addpath(genpath(pwd));
warning('off', 'all');


% parameters
num_cv = 5;
misRate = 0.1;
param.alpha   = 0.01;
param.gamma   = 10;
param.lamda   = 0.001;
param.lamda1   =10;
param.maxIter = 50;
param.minimumLossMargin = 0.01;
param.outputtempresult  = 0;
param.drawConvergence   = 0;
TSKoptions.k=3;
TSKoptions.h=10;


load('demo.mat');
if exist('train_data','var')==1
    data=[train_data;test_data];
    target=[train_target,test_target];
    clear train_data test_data train_target test_target
end
if exist('dataset','var')==1
    data = data;
    target = target ;
    clear dataset class
end
target = 0.5*target + 0.5;
data = (mapminmax(data',0,1))';


[v,b] = gene_ante_fcm(data,TSKoptions);
[G_data] = calc_x_g(data,v,b);
train_data=G_data;
num_train = size(train_data,1);
rng(0); 
randorder = randperm(num_train);

t0 = clock;
for cv = 1:num_cv
    [X,Y,Xtst,Ytst ] = generateCVSet( train_data,target',randorder,cv,num_cv);
    if misRate > 0
        [ImcompleteTarget, ~, ~, realpercent]= getIncompleteTarget(Y,misRate,1);
        fprintf('\n-- Missing rate:%.1f, Real Missing rate %.3f\n',misRate, realpercent);
    end
    if misRate == 0
        ImcompleteTarget =Y;
    end
    modelMY  = M2FSAG(ImcompleteTarget, X, param);
    Xtst = Xtst';
    tstp = modelMY.P'*Xtst;
    tstp_y = round(tstp);
    tstp_y = (tstp_y >= 1);
    tstp_y = double(tstp_y);
    Ytst = Ytst';
    Result_M2FSAG(:,cv) = EvaluationAll(tstp_y,tstp,Ytst);
end



Avg_mean(:,1)=mean(Result_M2FSAG,2);
Avg_std(:,1)=std(Result_M2FSAG,1,2);
time = etime(clock, t0)/5;


fprintf('------------------------------------\n');
fprintf('Evalucation Metric    Mean    Std\n');
fprintf('------------------------------------\n');
fprintf('HammingLoss           %.4f  %.4f\r',Avg_mean(1,1),Avg_std(1,1));
fprintf('ExampleBasedAccuracy  %.4f  %.4f\r',Avg_mean(2,1),Avg_std(2,1));
fprintf('ExampleBasedPrecision %.4f  %.4f\r',Avg_mean(3,1),Avg_std(3,1));
fprintf('ExampleBasedRecall    %.4f  %.4f\r',Avg_mean(4,1),Avg_std(4,1));
fprintf('ExampleBasedFmeasure  %.4f  %.4f\r',Avg_mean(5,1),Avg_std(5,1));
fprintf('SubsetAccuracy        %.4f  %.4f\r',Avg_mean(6,1),Avg_std(6,1));
fprintf('LabelBasedAccuracy    %.4f  %.4f\r',Avg_mean(7,1),Avg_std(7,1));
fprintf('LabelBasedPrecision   %.4f  %.4f\r',Avg_mean(8,1),Avg_std(8,1));
fprintf('LabelBasedRecall      %.4f  %.4f\r',Avg_mean(9,1),Avg_std(9,1));
fprintf('LabelBasedFmeasure    %.4f  %.4f\r',Avg_mean(10,1),Avg_std(10,1));
fprintf('MicroF1Measure        %.4f  %.4f\r',Avg_mean(11,1),Avg_std(11,1));
fprintf('Average_Precision     %.4f  %.4f\r',Avg_mean(12,1),Avg_std(12,1));
fprintf('OneError              %.4f  %.4f\r',Avg_mean(13,1),Avg_std(13,1));
fprintf('RankingLoss           %.4f  %.4f\r',Avg_mean(14,1),Avg_std(14,1));
fprintf('Coverage              %.4f  %.4f\r',Avg_mean(15,1),Avg_std(15,1));
fprintf('AUC                   %.4f  %.4f\r',Avg_mean(16,1),Avg_std(16,1));
fprintf('------------------------------------\n');
